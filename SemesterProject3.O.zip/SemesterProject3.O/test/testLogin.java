/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.SQLException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*; 
import testCases.testcaseLogin;

/**
 *
 * @author ABDUL HADI
 */
public class testLogin {
    
    public testLogin() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
   @Test
   public void testlogin(){
       
   }
    


   @Test
    public void testLoginSuccess() { 
        testcaseLogin lg = new testcaseLogin(); 
        boolean result = lg.logintc("hadi", "111111");  
        assertEquals(result,true);
    }

//    @Test
//    public void testWrongUsername() { 
//        login lg = new login(); 
//        boolean result = lg.login("wrongUser", "111111"); 
//        assertEquals(result, "Login should fail with incorrect username");
//    }
//
//    @Test
//    public void testWrongPassword() { 
//        login lg = new login();
// 
//        boolean result = lg.login("hadi", "wrongPassword"); 
//        assertEquals(result, "Login should fail with incorrect password");
//    }
//
//    @Test
//    public void testBothIncorrect() {
//         
//        login lg = new login(); 
//        boolean result = lg.login("wrongUser", "wrongPassword"); 
//        assertEquals(result, "Login should fail with incorrect username and password");
//    }

    
    
    
    


    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
