
public class loadingBar_Script {
    
    public static void main(String[] args) {
        splash sp = new splash();
        sp.setVisible(true);
        
        
        for(int i=0; i<=100; i++){
            
            sp.br.setValue(i);
            sp.pr.setText(i+"");
            try{
            Thread.sleep(20);
            }
            
            catch(Exception e){System.out.println(e);}
            
        }
        
        login l = new login();
        l.setVisible(true);
        sp.dispose();
        
        
    }//end of main
    
}//end of class
