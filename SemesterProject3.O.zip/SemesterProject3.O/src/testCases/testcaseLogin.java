/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testCases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
  

/**
 *
 * @author ABDUL HADI
 */
public class testcaseLogin {
    public boolean logintc(String a,String b){
        try{
                Class.forName("com.mysql.jdbc.Driver");

                try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/evm","root","")) {
                    Statement stmt=con.createStatement();

                    ResultSet rs=stmt.executeQuery("select * from signup where name= '"+a+"' and pass= '"+b+"' ");
                    int rowcount=-1;//local variable

                    while(rs.next()){
                        rowcount++;
                    }//end of while

                    if(rowcount==0){
                        return true;
                    }

                    else{

                        JOptionPane.showMessageDialog(null, "email or password is incorrect");
                        System.out.println("data not found");
                        return false;
                    }

                }//end of inner try
            }//end if outer try
            catch(Exception e){ System.out.println(e);}
        return false;
        
    }
}
