 import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class server {
    
    public static String FAQ(String a){
        String answer="";
        if(a.matches("1")){
            answer= "it's piece of cake, just enter your name,email and password according to the proper guidelines and you're done signing up";
            return answer;
         }
        else if(a.matches("2")){
            answer= "you can cast vote by clicking only 1 party and once party selected click cast vote button";
            return answer;
         }
       else if(a.matches("3")){
            answer= "NO! you can not stand for election from this system, you'll have to visit election comission office physically";
            return answer;
         }
       else if(a.matches("4")){
            answer= "YES! consider yourself safe, your data is not used anywhere except as a vote";
            return answer;
         }
        else if(a.matches("5")){
            answer= "admin can see the results and will be announced soon...";
            return answer;
         }
        
        else
        return null;
    }
    
    

    public static void main(String args[]) throws IOException {
       
        Socket socket;
        InputStreamReader inputStreamReader;
        OutputStreamWriter outputStreamWriter;
        BufferedReader bufferedReader;
        BufferedWriter bufferedWriter;
        ServerSocket serversocket;

        serversocket = new ServerSocket(5555);
        while (true) {
            try {

                socket = serversocket.accept();

                inputStreamReader = new InputStreamReader(socket.getInputStream());
                outputStreamWriter = new OutputStreamWriter(socket.getOutputStream());
                bufferedReader = new BufferedReader(inputStreamReader);
                bufferedWriter = new BufferedWriter(outputStreamWriter);

                while (true) {
                  
                    String msgFromClient = bufferedReader.readLine();
                    System.out.println("Client: " + msgFromClient);
                    String ans = FAQ(msgFromClient);
                    bufferedWriter.write(ans);//answer from server to clint
                    bufferedWriter.newLine();
                    bufferedWriter.flush();

                    if (msgFromClient.equalsIgnoreCase("BYE")) {
                        break;
                    }
                   
                    break;

                }
                socket.close();
                inputStreamReader.close();
                outputStreamWriter.close();
                bufferedReader.close();
                bufferedWriter.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

