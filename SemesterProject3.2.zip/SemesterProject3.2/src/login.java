import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class login extends javax.swing.JFrame {

    String username;
    String pasword;

    /**
     * Creates new form login
     */
    public login() {
        initComponents();
        j3.setVisible(false);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        info = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        t1 = new javax.swing.JTextField();
        j3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        showpass = new javax.swing.JButton();
        t2 = new javax.swing.JPasswordField();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(650, 383));
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                formMousePressed(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("ELECTIONS MANAGEMENT SYSTEM");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 20, -1, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/faqs.png"))); // NOI18N
        jLabel9.setText("...");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 40, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1400, 80));

        info.setBackground(new java.awt.Color(0, 0, 0));
        info.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 102));
        jLabel2.setText("email");
        info.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 180, 60, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 102));
        jLabel3.setText("Password");
        info.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 220, 80, -1));

        jButton1.setBackground(new java.awt.Color(255, 255, 0));
        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 153));
        jButton1.setText("signup here!");
        jButton1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 2, 1, 1));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        info.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 360, 80, 30));

        t1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t1ActionPerformed(evt);
            }
        });
        info.add(t1, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 180, 198, -1));

        j3.setForeground(new java.awt.Color(255, 0, 51));
        j3.setText("...");
        info.add(j3, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 250, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("dont have an account?");
        info.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 360, -1, 30));

        jButton2.setBackground(new java.awt.Color(255, 255, 0));
        jButton2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 0, 153));
        jButton2.setText("login");
        jButton2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 2, 1, 1));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        info.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 260, 100, 30));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 0));
        jLabel6.setText("OR");
        info.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 330, -1, -1));

        jLabel7.setBackground(new java.awt.Color(255, 255, 0));
        jLabel7.setForeground(new java.awt.Color(255, 255, 0));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/login.png"))); // NOI18N
        info.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 180, 170, 150));

        showpass.setIcon(new javax.swing.ImageIcon(getClass().getResource("/passwordHidebutton.png"))); // NOI18N
        showpass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showpassActionPerformed(evt);
            }
        });
        info.add(showpass, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 220, 30, 20));
        info.add(t2, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 220, 198, -1));

        jLabel4.setForeground(new java.awt.Color(153, 255, 102));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/scale.png"))); // NOI18N
        info.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 90, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 51));
        jLabel8.setText("Login here!");
        info.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 20, -1, -1));

        getContentPane().add(info, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 1410, 790));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        signup su = new signup();
        su.setVisible(true);
        this.dispose();

    }//GEN-LAST:event_jButton1ActionPerformed

    private void t1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_t1ActionPerformed

    private void formMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_formMousePressed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
         
                                            
    String email, pass;
    email = t1.getText().trim();
    pass = t2.getText().trim();

    if (email.isEmpty() || pass.isEmpty()) {
        j3.setVisible(true);
        j3.setText("Enter missing info");
    } else {
        j3.setText("");

        // Check for admin login
        if (email.equals("admin") && pass.equals("admin123")) {
            // Open the admin interface
            Admin adminInterface = new Admin(); // Replace with the actual class for admin interface
            adminInterface.setVisible(true);
            this.dispose(); // Close the current window
        } else {
            // Connecting to the database
            try {
                Class.forName("com.mysql.jdbc.Driver");

                try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/evm", "root", "")) {
                    Statement stmt = con.createStatement();

                    ResultSet rs = stmt.executeQuery("select * from signup where email= '" + email + "' and pass= '" + pass + "' ");
                    boolean userFound = false;

                    while (rs.next()) {
                        userFound = true;
                    }

                    if (userFound) {
                        // Open the voting interface for a regular user
                        voting v = new voting();
                        v.GetName(email);
                        v.setVisible(true);
                        this.dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, "Email or password is incorrect");
                        System.out.println("Data not found");
                    }
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        }//end inner else database connectivity
    
}//end else

    }//GEN-LAST:event_jButton2ActionPerformed

    private void showpassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showpassActionPerformed
        // TODO add your handling code here:
        if (t2.getEchoChar() == '*') {
            t2.setEchoChar((char) 0); // Show password
            showpass.setText("Hide Password");
        } else {
            t2.setEchoChar('*'); // Hide password
            showpass.setText("Show Password");
        }

    }//GEN-LAST:event_showpassActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel info;
    private javax.swing.JLabel j3;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton showpass;
    private javax.swing.JTextField t1;
    private javax.swing.JPasswordField t2;
    // End of variables declaration//GEN-END:variables
}
