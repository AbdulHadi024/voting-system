/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testCases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
  

/**
 *
 * @author ABDUL HADI
 */
public class testcaseLogin {
    public boolean logintc(String a,String b){
        try{
                Class.forName("com.mysql.jdbc.Driver");

                try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/evm","root","")) {
                    Statement stmt=con.createStatement();

                    ResultSet rs=stmt.executeQuery("select * from signup where name= '"+a+"' and pass= '"+b+"' ");
                    int rowcount=-1;//local variable

                    while(rs.next()){
                        rowcount++;
                    }//end of while

                    if(rowcount==0){
                        return true;
                    }

                    else{

                        JOptionPane.showMessageDialog(null, "email or password is incorrect");
                        System.out.println("data not found");
                        return false;
                    }

                }//end of inner try
            }//end if outer try
            catch(Exception e){ System.out.println(e);}
        return false;
        
    }



    public boolean CheckAlredyVoted(String name){
        int count=-1;
          try{
                Class.forName("com.mysql.jdbc.Driver");

                try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/evm","root","")) {
                    Statement stmt=con.createStatement();

                    ResultSet rs=stmt.executeQuery("select name from votes where name = '"+name+"'  "); 
                    while(rs.next()){
                        count++;
                         
                    }//end of while 
                    
                    if(count==-1){
                        return true;
                    }
                    else{
                        return false;
                    }

                }//end of inner try
            }//end if outer try
            catch(Exception e){ System.out.println(e);}
          return false;
    }
    
    
        
    public boolean GetName(String a){
        String temp=null;
        
        temp=a;
        
        if(temp.matches("ALI")){
            return true;
        }
        else{
            return false;
        }
    }
    
    
    public boolean CheckSignUpSuccess(String name, String email, String pass ){
        try{  
        Class.forName("com.mysql.jdbc.Driver");  
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/evm","root","")) {
           Statement stmt=con.createStatement();
        
        stmt.executeUpdate("INSERT into signup VALUES ( '"+name+"' , '"+email+"' , '"+pass+"') ");
         
            return true;
         }//end of inner try
    }//end if outer try
            catch(Exception e){ System.out.println(e);}
        return false;
    
    }
    
}

