 
import org.junit.Test;
import static org.junit.Assert.*; 
import testCases.testcaseLogin;
 
public class testLogin {
    
     

   @Test
    public void testLoginSuccess() { 
        testcaseLogin lg = new testcaseLogin(); 
        boolean result = lg.logintc("hadi", "111111");  
        assertEquals(result,true);
    }

 
     @Test
    public void CheckAlredyVotedPerson() { 
        testcaseLogin lg = new testcaseLogin(); 
        boolean result = lg.CheckAlredyVoted("jaduu@email.com");
        assertEquals(result,false);
    }

    @Test
    public void CheckNOTAlredyVotedPerson() { 
        testcaseLogin lg = new testcaseLogin(); 
        boolean result = lg.CheckAlredyVoted("jaduu@email.com");
        assertEquals(result,false);
    }
    
     @Test
    public void CheckNameVarified() { 
        testcaseLogin lg = new testcaseLogin(); 
        boolean result = lg.GetName("ALI");
        assertEquals(result,true);
    }
    
      @Test
    public void CheckNameNOTVarified() { 
        testcaseLogin lg = new testcaseLogin(); 
        boolean result = lg.GetName("ALIi");
        assertEquals(result,false);
    }
    
    @Test
    public void CheckSuccessfullSignUp() { 
        testcaseLogin lg = new testcaseLogin(); 
        boolean result = lg.CheckSignUpSuccess("BAG", "bag123.email.com", "bag675");
        assertEquals(result,true);
    }
    
        
    
}
